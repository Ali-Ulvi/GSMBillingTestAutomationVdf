package m;


import javax.swing.*;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.JTextComponent;
import javax.swing.text.TextAction;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class CutCopyPastActionSupport {
    private JMenu jMenu;
    JPopupMenu popupMenu = new JPopupMenu();

    public CutCopyPastActionSupport() {
        init();
    }

    private void init() {
        jMenu = new JMenu(" Edit ");
        addAction(new DefaultEditorKit.CopyAction(),  "Copy" );
        addAction(new DefaultEditorKit.PasteAction(),   "Paste" );
        addAction(new DefaultEditorKit.CutAction(),   "Cut" );

    }

    private void addAction(TextAction action,   String text) {

        action.putValue(AbstractAction.NAME, text);
        jMenu.add(new JMenuItem(action));
        popupMenu.add(new JMenuItem(action));
    }

    public void setPopup(JTextComponent... components){
        if(components == null){
            return;
        }
        for (JTextComponent tc : components) {
            tc.setComponentPopupMenu(popupMenu);
        }
    }

    public JMenu getMenu() {
        return jMenu;
    }
}
