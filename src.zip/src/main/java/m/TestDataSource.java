package m;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class TestDataSource {

        private  final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
        private  final String DB_CONNECTION = "jdbc:oracle:thin:@172.31.70.164:1526:KNNBGFD0";
        private  final String DB_USER = "ARBOR";
        private  final String DB_PASSWORD = "arb135bfd";
        private Connection dbConnection = null;

        TestDataSource(){
            dbConnection = getDBConnection();
        }

    String getDataIndIptJrn(String campCode) {

        if (true) {
            dbConnection = getDBConnection();
        }
        Statement statement = null;
        String selectTableSQL = "SELECT SUMMARY_CODE from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%data ind ipt%'";
        try {
            statement = dbConnection.createStatement();
            System.out.println(selectTableSQL);
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                String r = rs.getString("SUMMARY_CODE");
                System.out.println(r);
                return r;
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return "testDataNotFound";
    }
    String getVoiceIndIptJrn(String campCode) {

        if (true) {
            dbConnection = getDBConnection();
        }
        Statement statement = null;
        String selectTableSQL = "SELECT SUMMARY_CODE from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%voice ind ipt%'";
        try {
            statement = dbConnection.createStatement();
            System.out.println(selectTableSQL);
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                String r = rs.getString("SUMMARY_CODE");
                System.out.println(r);  return r;
            }
            statement.close();
        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }        return "testDataNotFound";

    }



    String getDataIndJrn(String campCode) {

        if (true) {
            dbConnection = getDBConnection();
        }
        Statement statement = null;
        String selectTableSQL = "SELECT SUMMARY_CODE from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%data ind%' and TURKISH_DESCR not like '%ind ipt%'";
        try {
            statement = dbConnection.createStatement();
            System.out.println(selectTableSQL);
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                String r = rs.getString("SUMMARY_CODE");
                System.out.println(r);return r;
            }
            statement.close();
        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }        return "testDataNotFound";

    }
    String getVoiceIndJrn(String campCode) {

        if (true) {
            dbConnection = getDBConnection();
        }
        Statement statement = null;
        String selectTableSQL = "SELECT SUMMARY_CODE from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%voice ind%' and TURKISH_DESCR not like '%ind ipt%'";
        try {
            statement = dbConnection.createStatement();
            System.out.println(selectTableSQL);
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                String r = rs.getString("SUMMARY_CODE");
                System.out.println(r);return r;
            }
            statement.close();
        } catch (SQLException e) {

            e.printStackTrace();

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }return "testDataNotFound:getVoiceIndJrn";
    }
        String getDataIndInv(String campCode) {

            if (true) {
                dbConnection = getDBConnection();
            }
            Statement statement = null;
            String selectTableSQL = "SELECT CBU_INVOICE_TAG from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%data ind%' and TURKISH_DESCR not like '%ind ipt%'";
            try {
                statement = dbConnection.createStatement();
                System.out.println(selectTableSQL);
                ResultSet rs = statement.executeQuery(selectTableSQL);
                while (rs.next()) {
                    String r = rs.getString("CBU_INVOICE_TAG");
                    System.out.println(r);
                    return r;
                }
                statement.close();
            } catch (SQLException e) {

                System.out.println(e.getMessage());

            } finally {
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (dbConnection != null) {
                    try {
                        dbConnection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }        return "testDataNotFound:getDataIndInv";

        }

    String getDataIndIptInv(String campCode) {

        if (true) {
            dbConnection = getDBConnection();
        }
        Statement statement = null;
        String selectTableSQL = "SELECT CBU_INVOICE_TAG from arbor.MAF_KENAN_JNL where Product_code='"+campCode+"' and TURKISH_DESCR like '%ind ipt%'";
        try {
            statement = dbConnection.createStatement();
            System.out.println(selectTableSQL);
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                String r = rs.getString("CBU_INVOICE_TAG");
                System.out.println(r);
            }
            statement.close();
        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }        return "testDataNotFound:getDataIndInv";

    }

        void close(){
            try {
                dbConnection.close();
                dbConnection=null;
            } catch (SQLException e) {
                e.printStackTrace();                dbConnection=null;

            }
        }
        private Connection getDBConnection() {

            try {

                Class.forName(DB_DRIVER);

            } catch (ClassNotFoundException e) {

                System.out.println(e.getMessage());

            }

            try {

                dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER,
                        DB_PASSWORD);
                return dbConnection;

            } catch (SQLException e) {

                System.out.println(e.getMessage());

            }

            return dbConnection;

        }


}
