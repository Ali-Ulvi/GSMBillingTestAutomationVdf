package m;

import com.jcraft.jsch.*;
import org.apache.poi.ss.formula.eval.NotImplementedException;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 * Ali Ulvi Talipoglu
 * 2018-2019
 */
public class App {
    public static Config c = Config.getInstance();
    public final static String MEDIATION_HOST = c.med_ip;
    public final static String MEDIATION_USER = c.med_user;
    public final static String MEDIATION_PW = c.med_pw;
    public final static String CCS_HOST = c.CCS_IP;
    public final static String CCS_USER = c.CCS_user;
    public final static String CCS_PW = c.CCS_PW;
    public final static String KENAN_HOST = c.kenanIp;
    public final static String KENAN_USER = "arbor";
    public final static String KENAN_PW = c.arbor_pw;
    final static String batchusrpw = c.batchusr_pw;
    public final static String mgrin = c.ccs_mgr_path;
    public final static String monin = c.ccs_mon_path;
    final static String mgrout = c.ccs_mgr_out_path;
    final static String monout = c.ccs_mon_out_path;
    public static Logger tb = null;
    public static String dir = "";
    static File fileDir = null;
    public static String msisdn, params;
    public static ArrayList<String> cdrs;
    public static boolean s;

    public static void main1(String[] args) {

        if (args.length < 1) {

            //test();
            print("Usage: java -jar OtoCBU.jar <msisdn> [-d<dateOfCDR>] [-k\"<grepKey1|grepKey2..>\"]\n " + "dateOfCDR option is to search that month's archived cdrs instead of today's.\n grepkeys parameters are prices or offer or product keys that should be filtered in, to avoid (filter out) unwanted CDRs.\n" +
                    " Example: java -jar OtoCBU.jar 5491112233\n Example: java -jar OtoCBU.jar 5480001122 -d201810 \n Example: java -jar OtoCBU.jar 5480001122 -d201810 -k\"11000000|249000000|375000000\"\n Example: java -jar OtoCBU.jar 5480001122 -k\"11000000|249000000|375000000\"");
            print("INFO : Sysdate may need to be TODAY for healthy rating. jar will ask you to change sysdate before BIP");
            System.exit(9);
        }

        print("Started");
        if (args.length == 2) {
            Ssh s=new Ssh("172.28.183.18","root","root");
            s.run("/OKSIJEN_PCRF/oksijen_ui 0 9009",args[0],args[1]);            System.exit(0);
        }
        if (args.length == 1) {
           new gfep(args[0]);  System.exit(0);
        }
        long start = System.currentTimeMillis();
        msisdn = args[0];
        params = "";

        String moncdr = null;
        s = true;//stopmode
        boolean backout = false;//rollback bip and postbill
        String campCode = "";
        boolean auto = false;
        cdrs = new ArrayList();
        String iTag_price = "", mafFee = "", discAmnt = "", penalty = "";
        String journalTagsPrices = "", mDiscountPercent = "";
        for (int i = 1; i < args.length; i++) {
            if (args[i].equals("true") || args[i].equals("false")) {
                break;
            }
            if (args[i].startsWith("-da")) {
                discAmnt = args[i].substring(3);
            } else if (args[i].contains("-k") || args[i].contains("-d"))
                params += " " + args[i].replace("|", "_").replace(",", "_");
            else if (args[i].startsWith("-p")) {
                penalty = args[i].substring(2);
            } else if (args[i].startsWith("-c")) {
                campCode = args[i].substring(2);
            }
            if (args[i].startsWith("-i")) {
                iTag_price = args[i].substring(2);
            }
            if (args[i].startsWith("-auto")) {
                auto = true;
            }
            if (args[i].startsWith("-j")) {
                 journalTagsPrices = args[i].substring(2).replace(",", "_");
             }
            if (args[i].startsWith("-m")) {
                mDiscountPercent = args[i].substring(2);
            }
            if (args[i].startsWith("-t")) {
                mafFee = args[i].substring(2);
            }

        }
        DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd_HH_mm_ss");
        Date date = new Date();
        dir = "Testbook_" + msisdn + "_" + journalTagsPrices + "_" + (dateFormat.format(date)) + "\\";
        fileDir = new File(dir);
        fileDir.mkdirs();
        tb = new Testbook(dir + "Testbook_" + msisdn + "_" + journalTagsPrices + "_" + mDiscountPercent + ".txt").getLogger();

        if (args.length > 7) {
            Simple.cbJrn.setSelected(new Boolean(args[args.length - 1]));
            Simple.cbInv.setSelected(new Boolean(args[args.length - 2]));
            Simple.cbBip.setSelected(new Boolean(args[args.length - 3]));
            backout = (new Boolean(args[args.length - 4]));
            Simple.cbRate.setSelected(new Boolean(args[args.length - 5]));
            Simple.checkMed.setSelected(new Boolean(args[args.length - 6]));
            s = !new Boolean(args[args.length - 7]);

        }
        if (Simple.checkMed.isSelected() && Simple.cbRate.isSelected()) {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(CCS_USER, CCS_HOST, 22);
                session.setPassword(CCS_PW);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                System.out.println(CCS_USER + CCS_HOST + CCS_PW);
                session.setConfig(config);
                session.setConfig("kex", "diffie-hellman-group1-sha1");

                session.connect();

                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                print(String.format("cd " + c.cssScriptPath + ";filterCDR.sh %s \"%s\" ", msisdn, params));
                channel.setCommand(String.format("cd " + c.cssScriptPath + ";filterCDR.sh %s \"%s\" ", msisdn, params));
                channel.connect();

                String msg = null;
                while ((msg = in.readLine()) != null) {
                    System.out.println(msg);
                    if (msg.contains(" fees for ")) {
                        StringTokenizer st = new StringTokenizer(msg);
                        st.nextToken();
                        st.nextToken();
                        st.nextToken();
                        String cdrNameWithDot = st.nextToken();
                        cdrs.add(cdrNameWithDot.substring(0, cdrNameWithDot.lastIndexOf(".unl") + 4));
                    }
                }
                channel.disconnect();
                ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                for (int i = 0; i < cdrs.size(); i++) {
                    print(cdrs.get(i));
                    sftpChannel.get(c.cssScriptPath + cdrs.get(i), dir + cdrs.get(i));

                }
                print("cdr file count:" + cdrs.size());
                //print("INFO : Sysdate may need to be TODAY for healthy rating");
                sftpChannel.disconnect();


                session.disconnect();
                if (cdrs.size() == 0) {
                    tb.severe("No CCS CDR found");
                    System.exit(5);
                }

            } catch (Exception e) {
                e.printStackTrace();
                //System.out.println("CCS SSH OR ftp ERROR");
                tb.severe("CCS SSH OR ftp ERROR");
                System.exit(1);

            }
            print("Please, check CDR fees and press enter for Mediation, or type q and press enter to quit.");
            Scanner scanner = new Scanner(System.in);
            if (s) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("q"))
                    System.exit(3);
            }
            //PUT TO MEDIATION
            ArrayList<String> medCdrs = new ArrayList();
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(MEDIATION_USER, MEDIATION_HOST);
                session.setPassword(MEDIATION_PW);
                Properties config = new Properties();
                config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
                config.put("StrictHostKeyChecking", "no");

                session.setConfig(config);

                session.connect();
                ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                String monCode = "", mgrCode = "";
                for (int i = 0; i < cdrs.size(); i++) {
                    if (cdrs.get(i).contains("mon")) {
                        monCode = "mon";
                        sftpChannel.put(dir + cdrs.get(i), monin + cdrs.get(i));
                    } else {
                        mgrCode = "mgr";
                        sftpChannel.put(dir + cdrs.get(i), mgrin + cdrs.get(i));
                    }
                }

                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                print("Mediating...");
                channel.setCommand(String.format("cd script; ./checkMediation.sh " + msisdn + " " + monCode + mgrCode));
                channel.connect();

                String msg = null;
                boolean monExists = false, mgrExists = false;

                while ((msg = in.readLine()) != null) {
                    System.out.println(msg);
                    if (msg.equals("MGR CDR PROCESSED"))
                        mgrExists = true;
                    else if (msg.equals("MON CDR PROCESSED"))
                        monExists = true;
                    else if (msg.endsWith(".data"))
                        medCdrs.add(msg);

                }
                channel.disconnect();
                for (int i = 0; i < medCdrs.size(); i++) {
                    print("Getting " + medCdrs.get(i));
                    String ctrlFile = medCdrs.get(i).replace(".data", ".ctrl");
                    sftpChannel.get(medCdrs.get(i), dir + medCdrs.get(i).split("/")[7]);
                    sftpChannel.get(ctrlFile, dir + ctrlFile.split("/")[7]);

                }
                sftpChannel.disconnect();
                session.disconnect();
                if (medCdrs.size() == 0) {
                    tb.severe("No mediated CDR found. Check Mediation system");
                    print("No mediated CDR found. Press enter to continue or type q and press enter to quit");
                    if (s) {
                        String input = scanner.nextLine();
                        if (input.equalsIgnoreCase("q"))
                            System.exit(3);
                    } else
                        System.exit(3);
                }
            } catch (Exception e) {
                e.printStackTrace();
                //System.out.println("Mediation FTP ERROR");
                tb.severe("Mediation FTP ERROR");
                System.exit(3);

            }

            //put to kenan AND BILL!
            if (medCdrs.size() > 0) {
                try {
                    JSch jsch = new JSch();
                    Session session = jsch.getSession(KENAN_USER, KENAN_HOST, 22);
                    session.setPassword(KENAN_PW);
                    Properties config = new Properties();
                    config.put("StrictHostKeyChecking", "no");
                    session.setConfig(config);
                    session.connect();
                    ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                    sftpChannel.connect();
                    String filename = "";
                    for (int i = 0; i < medCdrs.size(); i++) {
                        filename = medCdrs.get(i).split("/")[7];
                        print("Sending " + filename);
                        sftpChannel.put(dir + filename, c.kenanPath + filename);
                        sftpChannel.put(dir + filename.replace(".data", ".ctrl"), c.kenanPath + filename.replace(".data", ".ctrl"));

                    }
                    sftpChannel.disconnect();
                    ChannelExec channel = (ChannelExec) session.openChannel("exec");
                    BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                    channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./rate.sh %s %s %s ", msisdn, medCdrs.get(0).split("/")[7], filename));
                    channel.connect();

                    String msg = null;
                    while ((msg = in.readLine()) != null) {
                        System.out.println(msg);
                    }
                    channel.disconnect();
                    session.disconnect();

                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("KENAN SSH OR ftp ERROR");
                    System.exit(22);

                }
            }
        } else if (Simple.cbRate.isSelected())
            new Unix.Rate();
        else if (Simple.checkMed.isSelected())
            new Unix.Mediator().Mediate();
        if (backout) {
            print("Please, set sysdate to after Cut-off date and press enter for BACKOUT of BIP&PostBill. Type q and press enter to quit.");
            Scanner scanner = new Scanner(System.in);
            if (s) {
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("q"))
                    System.exit(3);

            }
            new Backout();
        }
        if (Simple.cbBip.isSelected()) {
            print("Please, set sysdate to after Cut-off date and press enter for BIP. Type q and press enter to quit.");
            Scanner scanner = new Scanner(System.in);
            if (s) {
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("q"))
                    System.exit(3);
            }//BIP and INVOICE
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(KENAN_USER, KENAN_HOST, 22);
                session.setPassword(KENAN_PW);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                BufferedReader err = new BufferedReader(new InputStreamReader(channel.getErrStream()));

                channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./bip.sh %s ", msisdn));
                channel.connect();
                String msg, er = null;
                while ((msg = in.readLine()) != null || (er = err.readLine()) != null) {

                    if (msg != null) {
                        System.out.println(msg);
/*                        if (msg.contains("ERROR") || msg.contains("Error") || msg.contains("[E]")) {
                            tb.severe(msg);
                        }*/
                    }
                    if (er != null)
                        print(er);
                }
                channel.disconnect();
                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("KENAN SSH, FTP or File ERROR during BIP");
            }
        }
        TestDataSource ds = null;

        if (Simple.cbInv.isSelected()) {

            print("Press enter for Invoicing. Type q and press enter to quit.");
            Scanner scanner = new Scanner(System.in);
            if (s) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("q"))
                    System.exit(34);
            }
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession("batchusr", KENAN_HOST, 22);
                session.setPassword(batchusrpw);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                BufferedReader err = new BufferedReader(new InputStreamReader(channel.getErrStream()));

                channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./inv.sh %s", msisdn));
                channel.connect();
                String msg = "", er = "", xmlFile = null;
                while ((msg = in.readLine()) != null || (er = err.readLine()) != null) {
                    if (msg != null) {
                        System.out.println(msg);
                        if (msg.startsWith("invoice: /swstage/batchfs/Invoicing/format") && msg.endsWith(".xml")) {
                            xmlFile = msg.replace("invoice: ", "");
                        }
                    }
                    if (er != null)
                        print(er);
                }
                channel.disconnect();
                ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                if (xmlFile == null) {
                    // print("Invoice xml file could NOT be generated. Exiting automation");
                    tb.severe("Invoice xml file could NOT be generated. Check automation std output for the root cause.");
                    System.exit(12);
                }
                print("Downloading " + xmlFile);
                String xmlFileName = xmlFile.split("/")[5];
                SftpProgressMonitor monitor = new MyProgressMonitor("Invoice");
                sftpChannel.get(xmlFile, dir + xmlFileName, monitor);
                sftpChannel.disconnect();
                session.disconnect();
                InvoiceChecker invoiceChecker = new InvoiceChecker(dir + xmlFile.split("/")[5]);
                if (!iTag_price.isEmpty()) {
                    invoiceChecker.checkPrices(iTag_price.replace("_", ","));
                }

                if (!campCode.isEmpty()) {
                    ds = new TestDataSource();
                    invoiceChecker.checkPrices(ds.getDataIndInv(campCode) + "," + discAmnt);
                    if (!penalty.isEmpty()) {
                        invoiceChecker.checkPrices(ds.getDataIndIptInv(campCode) + "," + penalty);
                    }
                } else {
                    if (!discAmnt.isEmpty()) {
                        invoiceChecker.checkPrices("DT-INDIRI" + "," + discAmnt);
                    }

                    if (!penalty.isEmpty()) {
                        invoiceChecker.checkPrices("DT-INDIPT" + "," + penalty);
                    }
                }
                if (!mDiscountPercent.isEmpty()) {
                    invoiceChecker.checkMAFDiscountRatio(mDiscountPercent);
                }
                if (!mafFee.isEmpty()) {
                    invoiceChecker.checkPrices("DT-MAFALL," + mafFee);
                }
                if (!mafFee.isEmpty() || !mDiscountPercent.isEmpty()) {
                    invoiceChecker.checkMAFDataRatio("85");
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("KENAN SSH or File ERROR during Invoicing");
                System.exit(217);

            }
        }
        if (Simple.cbJrn.isSelected()) {
            print("Press enter for Journaling. Type q and press enter to quit.");
            Scanner scanner = new Scanner(System.in);
            if (s) {
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("q"))
                    System.exit(34);
            }//Journaling
            String xlsFile = null;
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession("batchusr", KENAN_HOST, 22);
                session.setPassword(batchusrpw);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                BufferedReader err = new BufferedReader(new InputStreamReader(channel.getErrStream()));
                String script = journalTagsPrices.isEmpty() && campCode.isEmpty() ? "jrn1.sh" : "jrn1Auto.sh";
                if (!campCode.isEmpty()) {
                    if (ds == null)
                        ds = new TestDataSource();
                    if (!journalTagsPrices.isEmpty())
                        journalTagsPrices += ",";
                    String pa = new BigDecimal(discAmnt).multiply(new BigDecimal("0.00000085")).toString();
                    pa = pa.replaceAll("(.*)\\.0+$", "$1");
                    pa = pa.replaceAll("(.*\\..{1,2}).*", "$1");
                    if (pa.contains("."))
                        pa += ".*";
                    journalTagsPrices += ds.getDataIndJrn(campCode) + "," + pa + ",";
                    pa = new BigDecimal(discAmnt).multiply(new BigDecimal("0.00000015")).toString();
                    pa = pa.replaceAll("(.*)\\.0+$", "$1");
                    pa = pa.replaceAll("(.*\\..{1,2}).*", "$1");
                    if (pa.contains("."))
                        pa += ".*";
                    journalTagsPrices += ds.getVoiceIndJrn(campCode) + "," + pa;
                    if (!penalty.isEmpty()) {
                        pa = new BigDecimal(penalty).multiply(new BigDecimal("0.00000085")).toString();
                        pa = pa.replaceAll("(.*)\\.0+$", "$1");
                        pa = pa.replaceAll("(.*\\..{1,2}).*", "$1");
                        if (pa.contains("."))
                            pa += ".*";
                        journalTagsPrices += "," + ds.getDataIndIptJrn(campCode) + "," + pa + ",";

                        pa = new BigDecimal(penalty).multiply(new BigDecimal("0.00000015")).toString();
                        pa = pa.replaceAll("(.*)\\.0+$", "$1");
                        pa = pa.replaceAll("(.*\\..{1,2}).*", "$1");
                        if (pa.contains("."))
                            pa += ".*";
                        journalTagsPrices += ds.getVoiceIndIptJrn(campCode) + "," + pa;
                    }
                    ds.close();
                }
                print(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./%s %s cbu '%s'", script, msisdn, journalTagsPrices));
                channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./%s %s cbu '%s'", script, msisdn, journalTagsPrices));
                channel.connect();
                String msg, er = null;
                while ((msg = in.readLine()) != null || (er = err.readLine()) != null) {

                    if (msg != null) {

                        if (msg.startsWith("/batchfs/Journal/Reports/") && msg.endsWith("xls")) {
                            xlsFile = msg;                            System.out.println(msg);

                        } else if (msg.contains("Journal Tag Success:")) {
                            tb.info(msg);
                        } else if (msg.contains("Journal ERROR:")) {
                            tb.severe(msg);
                        } else
                            System.out.println(msg);
                    }
                    if (er != null)
                        print(er);
                }
                channel.disconnect();
                ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                if (xlsFile == null) {
                    //print("Journal file could NOT be generated. Exiting automation");
                    tb.severe("Journal file could NOT be generated. Check automation std output");
                    long milisec = System.currentTimeMillis() - start;
                    print("OtoCBU run time: " + milisec / 1000 / 60 + " minutes including user-input waitings");
                    System.exit(111);
                }
                SftpProgressMonitor monitor = new MyProgressMonitor("Journal");
                print("Downloading " + xlsFile);
                sftpChannel.get(xlsFile, dir + xlsFile.split("/")[4], monitor);
                sftpChannel.disconnect();
                session.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("KENAN SSH or File ERROR during Journaling");
                System.exit(27);

            }
            File file = new File(dir + xlsFile.split("/")[4]);

            try {
                Desktop desktop = Desktop.getDesktop();

                // Open a file using the default program for the file type.
                desktop.open(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        long milisec = System.currentTimeMillis() - start;
        print("Automation completed in " + milisec / 1000 / 60 + " minutes including user-input waitings");

/*
        String dir = System.getProperty("user.dir") + "\\";
        dir = dir.replace("/", "\\");
        Runtime.getRuntime().exec("CMD /C START \"" + dir + xlsFile.split("/")[4] + "\"");
*/
    }

    static StringBuilder sb = new StringBuilder();

    static void checkInvoiceTags(String[] iTag_price, String file) {
        //Not Working. use the class instead
        for (int i = 0; i < iTag_price.length; i += 2) {
            String searchStr = String.format("<%s>%s</%s>", iTag_price[i], iTag_price[i + 1], iTag_price[i]);
            if (sb.length() > 0) {
                if (sb.toString().contains(searchStr)) {
                    //print("Invoice tag found Successfully " + searchStr);
                    tb.info("Invoice tag found Successfully " + searchStr);
                } else {
                    //print("ERR: INVOICE TAG NOT FOUND: " + searchStr);
                    tb.severe("INVOICE TAG NOT FOUND: " + searchStr);

                }
            } else {
                Scanner scanner = null;
                boolean found = false;
                try {
                    scanner = new Scanner(new File(file));

                    String currentLine;
                    while (scanner.hasNext()) {
                        currentLine = scanner.nextLine();
                        if (currentLine.contains(searchStr)) {
                            tb.info("Invoice tag found Successfully " + searchStr);
                            found = true;
                        }
                        sb.append(currentLine);

                    }
                    if (!found) {
                        //print("ERR: INVOICE TAG NOT FOUND: " + searchStr);
                        tb.severe("ERR: INVOICE TAG NOT FOUND: " + searchStr);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    tb.severe("Exception checking invoice tags");
                }
            }
        }
        //print(sb.toString());
    }


    public static void print(String s) {
        System.out.println(s);
    }

    private static void print(long s) {
        System.out.println(s);
    }

    public static void test() throws IOException {
        File file = new File("data.xlsx");

        try {
            Desktop desktop = Desktop.getDesktop();

            // Open a file using the default program for the file type.
            desktop.open(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class MyProgressMonitor implements SftpProgressMonitor {
        ProgressMonitor monitor;
        long count = 0;
        long max = 0;
        String file;

        public MyProgressMonitor() {
        }

        public MyProgressMonitor(String file) {
            this.file = file;
        }

        public void init(int op, String src, String dest, long max) {
            this.max = max;
            monitor = new ProgressMonitor(null,
                    ((op == SftpProgressMonitor.PUT) ?
                            "put" : "Downloading " + file) + ": " + src,
                    "", 0, (int) max);
            count = 0;
            percent = -1;
            monitor.setProgress((int) this.count);
            monitor.setMillisToDecideToPopup(1000);
        }

        private long percent = -1;

        public boolean count(long count) {
            this.count += count;

            if (percent >= this.count * 100 / max) {
                return true;
            }
            percent = this.count * 100 / max;

            monitor.setNote("Completed " + this.count + "(" + percent + "%) out of " + max + ".");
            monitor.setProgress((int) this.count);

            return !(monitor.isCanceled());
        }

        public void end() {
            monitor.close();
        }
    }
}
