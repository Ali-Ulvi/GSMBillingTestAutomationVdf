package m;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {
    String  arbor_pw;
    String batchusr_pw;
    String kenanIp;
    String CCS_IP;
    String CCS_user;
    String CCS_PW;
    String med_ip;
    String med_user;
    String med_pw;
    String ccs_mon_path;
    String ccs_mgr_path;
    String ccs_mon_out_path;
    String ccs_mgr_out_path;
    public String kenanPath;
    public String cssScriptPath;

    private Config() {
        InputStream input = null;

        try {

            input = new FileInputStream("CBU_config.txt");

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            arbor_pw = prop.getProperty("arbor_unix_password");
            ccs_mon_path = prop.getProperty("Mon_CDR_input_path");
            ccs_mgr_path = prop.getProperty("Mgr_CDR_input_path");
            ccs_mon_out_path = prop.getProperty("Mon_CDR_output_path");
            ccs_mgr_out_path = prop.getProperty("Mgr_CDR_output_path");
            CCS_IP = prop.getProperty("CCS_IP");
            CCS_user = prop.getProperty("CCS_user");
            CCS_PW = prop.getProperty("CCS_Password");
            med_ip = prop.getProperty("Mediation_IP");
            med_user = prop.getProperty("Mediation_User");
            med_pw = prop.getProperty("Mediation_Password");
            batchusr_pw = prop.getProperty("batchusr_unix_password");
            kenanIp = prop.getProperty("kenan_unix_ip");
            kenanPath = prop.getProperty("kenan_cdr_path");
            cssScriptPath = prop.getProperty("CCS_Script_path");


        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }//singleton

    private static Config obj = new Config();
    private Properties prop = new Properties();

    static Config getInstance() {
        return obj;
    }


}
