package m;

import java.io.IOException;
import java.util.logging.*;

public class Testbook {
    FileHandler fh;
    ConsoleHandler ch;
    Logger logger = Logger.getLogger("Ali.Ulvi");

     Testbook(String filename){
        try {
            fh = new FileHandler(filename);
            ch = new ConsoleHandler();
        } catch (IOException e) {
            e.printStackTrace();
        }
        logger.addHandler(fh);
        logger.addHandler(ch);
         MyFormatter formatter = new MyFormatter();
        fh.setFormatter(formatter);
        ch.setFormatter(formatter);
         logger.setUseParentHandlers(false);

    }

    public Logger getLogger() {
        return logger;
    }
    class MyFormatter extends Formatter {

        /* (non-Javadoc)
         * @see java.util.logging.Formatter#format(java.util.logging.LogRecord)
         */
        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder();
            sb.append("["+record.getLevel().toString().replace("SEVERE","ERROR")+"] ");
            sb.append(record.getMessage()).append(System.getProperty("line.separator"));
            return sb.toString();
        }
    }
}
