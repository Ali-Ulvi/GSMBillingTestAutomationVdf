package m;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static m.App.tb;

public class InvoiceChecker {
    private StringBuilder sb = new StringBuilder();

    InvoiceChecker(String file) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String st;
            while ((st = br.readLine()) != null)
                sb.append(st);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    BigDecimal getTagValue(String tag){
        String pattern = String.format("<%s>(\\d*)</%s>", tag , tag);
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(sb.toString());
        if (m.find()) {
            tb.info(tag +" is "+m.group(1));
            if (m.group(1).isEmpty())
                return BigDecimal.ZERO;
            else{
                return new BigDecimal(m.group(1));
            }
        } else {
            tb.severe(tag+" tag does NOT exist in invoice");
            return BigDecimal.ZERO;
        }
    }
    void checkMAFDiscountRatio(String ratio){
        if (getTagValue("DT-MAFALL").equals(BigDecimal.ZERO)) {
            tb.severe("Tariff Price is 0");return;
        }
        BigDecimal invRatio = getTagValue("DT-INDIRI").divide(getTagValue("DT-MAFALL"),6, RoundingMode.HALF_UP).multiply(new BigDecimal("100"));
        tb.info("Discount ratio in invoice is: " + invRatio.toString());
        if (invRatio.subtract(new BigDecimal(ratio)).abs().compareTo(new BigDecimal("0.01")) > 0){
            tb.severe("Discount ratio in invoice is different than expected. Expected is "+ ratio+" but actual is "+ invRatio.toString());
        }
    }
    void checkMAFDataRatio(String ratio){

        if (getTagValue("DT-MAFALL").equals(BigDecimal.ZERO)) {
            tb.severe("Tariff Price is 0");return;
        }
        BigDecimal invRatio = getTagValue("DT-BNDTOP").divide(getTagValue("DT-MAFALL"),6, RoundingMode.HALF_UP).multiply(new BigDecimal("100"));
        tb.info("Data fee ratio in invoice is: " + invRatio.toString());
        if (invRatio.subtract(new BigDecimal(ratio)).abs().compareTo(new BigDecimal("0.01")) > 0){
            tb.severe("Data fee ratio in invoice is different than expected. Expected is "+ ratio+" but actual is "+ invRatio.toString());
        }
    }

    void checkPrices(String tagsAndPrices) {
        String[] iTag_price = tagsAndPrices.split(",");
        for (int i = 0; i < iTag_price.length; i += 2) {
            String searchStr = String.format("<%s>%s</%s>", iTag_price[i], iTag_price[i + 1], iTag_price[i]);
            if (sb.toString().contains(searchStr)) {
                tb.info("Invoice tag found Successfully: " + searchStr);

            } else {
                System.out.println(sb.toString());
                tb.severe("INVOICE TAG NOT FOUND: " + searchStr);
                String pattern = String.format("<%s>.*</%s>", iTag_price[i], iTag_price[i]);
                Pattern r = Pattern.compile(pattern);
                Matcher m = r.matcher(sb.toString());
                if (m.find()) {
                    tb.severe("Wrong amount: " + m.group(0));
                } else {
                    tb.severe("Tag not exists");
                }
            }
        }
    }
}
