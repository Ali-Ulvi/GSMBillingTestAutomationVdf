package m;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Properties;

import static m.App.*;

public class Backout {
    Backout() {
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(KENAN_USER, KENAN_HOST, 22);
            session.setPassword(KENAN_PW);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            BufferedReader err = new BufferedReader(new InputStreamReader(channel.getErrStream()));

            channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./backoutPostBillAndBip.sh %s", msisdn));
            channel.connect();
            String msg, er  = null;
            while ((msg = in.readLine()) != null || (er = err.readLine()) != null) {
                if (msg != null) {
                    System.out.println(msg);
                    if(msg.contains("ERROR")||msg.contains("Error")||msg.contains("[E]")){
                        tb.severe(msg);
                    }
                }
                if (er != null)
                    System.out.println(er);
            }
            channel.disconnect();
            session.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("KENAN SSH ERROR");
            System.exit(22);

        }
    }
}
