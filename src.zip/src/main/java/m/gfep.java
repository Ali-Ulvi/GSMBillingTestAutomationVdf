package m;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Properties;

import static m.App.*;

public class gfep {
    gfep(String msisdn) {
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession("gfep", "10.144.11.99", 22);
            session.setPassword("Huawei123");
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            //System.out.println(user + ip + pw);
            session.setConfig(config);
            session.setConfig("kex", "diffie-hellman-group1-sha1");
            session.connect();
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            BufferedReader err = new BufferedReader(new InputStreamReader(channel.getErrStream()));

            channel.setCommand(String.format("cd /home/gfep/fep/SMSC;aut_checks.sh %s", msisdn));
            //channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./backoutPostBillAndBip.sh %s", msisdn));
            channel.connect();
            String msg, er  = null;
            while ((msg = in.readLine()) != null || (er = err.readLine()) != null) {
                if (msg != null) {
                    System.out.println(msg);
                }
                if (er != null)
                    System.out.println(er);
            }
            channel.disconnect();
            session.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("KENAN SSH ERROR");
            System.exit(22);

        }
    }
}
