package m;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Crd {
    private Map<String, Integer> colMapByName, jnlColMap;
    private XSSFSheet campaignSheet, jrnSheet;
    private FormulaEvaluator evaluator;
    private int campaignCodeIndex = -1;

    public Crd(File someFile) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(someFile);
        XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
        evaluator = workbook.getCreationHelper().createFormulaEvaluator();

        // campaignSheet = workbook.getSheet("NEW Campaigns for MC");
        campaignSheet = workbook.getSheetAt(0);

        int rowNum = campaignSheet.getLastRowNum() + 1;
        int colNum = campaignSheet.getRow(1).getLastCellNum();

        /* first row data for column names and index */

        colMapByName = new HashMap<String, Integer>();
        Iterator<Cell> it = campaignSheet.getRow(1).cellIterator();
        int jj = 0;
        while (it.hasNext()) {
Cell c =it.next();
            colMapByName.put(getCellStr(c),c.getColumnIndex());
            jj++;
        }
        try {
            Iterator<Cell> it2 = campaignSheet.getRow(0).cellIterator();
            int jjj = 0;
            while (it2.hasNext()) {

                Cell c =it2.next();

                colMapByName.put(getCellStr(c),c.getColumnIndex());
                jjj++;
            }
        }catch (Exception e){
            System.out.println("kampanya sayfasi ilk satiri bos");
        }
        System.out.println("campaignCodeIndex"+campaignCodeIndex+"--"+colMapByName.get("Campaign Code")+colMapByName);
        campaignCodeIndex = colMapByName.get("Campaign Code");
        //if first row empty POI exceptions

        jrnSheet = workbook.getSheet("JNL");
        colNum = jrnSheet.getRow(0).getLastCellNum();

        jnlColMap = new HashMap<String, Integer>();
        if (jrnSheet.getRow(0).cellIterator().hasNext()) {
            for (int j = 0; j < colNum; j++) {
                jnlColMap.put(getCellStr(jrnSheet.getRow(0).getCell(j)), j);
            }
        }
    }


    private String getCellStr(Cell cell) {
        if (cell == null)
            return "";
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_STRING:
                return cell.getStringCellValue();


            case Cell.CELL_TYPE_FORMULA:
                System.out.println("formula"+evaluator.evaluateFormulaCell(cell));
                return Integer.toString(evaluator.evaluateFormulaCell(cell));


            case Cell.CELL_TYPE_NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return Double.toString(cell.getNumericCellValue());
                }

            case Cell.CELL_TYPE_BLANK:
                return "";

            case Cell.CELL_TYPE_BOOLEAN:
                System.out.println("bool");
                return Boolean.toString(cell.getBooleanCellValue());

        }
        return "UnknownDataTypeInXls";
    }

    Object[] getCampaignCodes() {
        ArrayList campaigns = new ArrayList();
        for (Row row : campaignSheet) { // For each Row.
            if (!getCellStr(row.getCell(campaignCodeIndex)).isEmpty())
                campaigns.add(getCellStr(row.getCell(campaignCodeIndex))); // Get the Cell at the Index / Column you want.
        }
        if (campaigns.size() > 0)
            campaigns.remove(0);
        return campaigns.toArray();
    }


    private int getTaksitSayisi(String campaignCode) {
        int rowNum = -1;
        for (Row row : campaignSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                rowNum = cell.getRowIndex();
                return (int) row.getCell(10).getNumericCellValue();
            }
        }
        return -1;
    }

    private long getTaksitAmount(String campaignCode) {
        int campaignCodeIndex = colMapByName.get("Campaign Code");
        for (Row row : campaignSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                return new Double(row.getCell(colMapByName.get("Handset Installment Fee")).getNumericCellValue() * 1000000).longValue();
            }
        }
        return -1;
    }

    private long getCezaAmount(String campaignCode) {
        int campaignCodeIndex = colMapByName.get("Campaign Code");
        for (Row row : campaignSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                return (long) (row.getCell(colMapByName.get("Handset Installment Fee")).getNumericCellValue()) * 1000000 * (getTaksitSayisi(campaignCode) - 1);
            }
        }
        return -1;
    }

    private String removeDotZero(Double d) {
        if (String.valueOf(d).endsWith(".0")) {
            return String.valueOf(d).substring(0, String.valueOf(d).length() - 2);
        }
        return String.valueOf(d);
    }

    private String getCezaInvoiceTag(String campaignCode) {
        int campaignCodeIndex = jnlColMap.get("PRODUCT_CODE");
        for (Row row : jrnSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                if (getCellStr(row.getCell(jnlColMap.get("TURKISH_DESCR"))).contains(" ceza"))
                    return ((jnlColMap.get("CBU  INVOICE_TAG")) == null ? row.getCell(jnlColMap.get("CBU INVOICE_TAG")) : row.getCell(jnlColMap.get("CBU  INVOICE_TAG"))).getStringCellValue();
            }
        }
        return "NotFound";
    }

    private String getTaksitInvoiceTag(String campaignCode) {
        int campaignCodeIndex = jnlColMap.get("PRODUCT_CODE");
        for (Row row : jrnSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                if (getCellStr(row.getCell(jnlColMap.get("TURKISH_DESCR"))).contains(" taksit"))
                    return ((jnlColMap.get("CBU  INVOICE_TAG")) == null ? row.getCell(jnlColMap.get("CBU INVOICE_TAG")) : row.getCell(jnlColMap.get("CBU  INVOICE_TAG"))).getStringCellValue();
            }
        }
        return "NotFound";
    }

    String getInvoiceCheckStr(String campaignCode) {
        if (getCezaInvoiceTag(campaignCode).equals(getTaksitInvoiceTag(campaignCode))) {
            return String.format("%s,%d", getCezaInvoiceTag(campaignCode), getTaksitAmount(campaignCode) * getTaksitSayisi(campaignCode));
        } else
            return String.format("%s,%d,%s,%d", getTaksitInvoiceTag(campaignCode), getTaksitAmount(campaignCode), getCezaInvoiceTag(campaignCode), getCezaAmount(campaignCode));
    }

    private String getCezaJrnTag(String campaignCode) {
        int campaignCodeIndex = jnlColMap.get("PRODUCT_CODE");
        for (Row row : jrnSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                if (getCellStr(row.getCell(jnlColMap.get("TURKISH_DESCR"))).contains(" ceza"))
                    return row.getCell(jnlColMap.get("SUMMARY_CODE")).getStringCellValue();
            }
        }
        return "NotFound";
    }

    private String getTaksitJrnTag(String campaignCode) {
        int campaignCodeIndex = jnlColMap.get("PRODUCT_CODE");
        for (Row row : jrnSheet) { // For each Row.
            Cell cell = row.getCell(campaignCodeIndex); // Get the Cell at the Index / Column you want.
            if (getCellStr(cell).equals(campaignCode)) {
                if (getCellStr(row.getCell(jnlColMap.get("TURKISH_DESCR"))).contains(" taksit"))
                    return row.getCell(jnlColMap.get("SUMMARY_CODE")).getStringCellValue();
            }
        }
        return "NotFound";
    }

    String getJournalCheckStr(String campaignCode) {
        if (getCezaJrnTag(campaignCode).equals(getTaksitJrnTag(campaignCode))) {
            return String.format("%s,%d", getCezaJrnTag(campaignCode), getTaksitAmount(campaignCode) * getTaksitSayisi(campaignCode));
        } else
            return String.format("%s,%d,%s,%d", getTaksitJrnTag(campaignCode), getTaksitAmount(campaignCode) / 1000000, getCezaJrnTag(campaignCode), getCezaAmount(campaignCode) / 1000000);
    }
}
