package m;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.*;
import java.util.Properties;


public class Ssh {
    String user, pw, ip;
    BufferedReader in;
    BufferedReader err;
    BufferedWriter w;
    ChannelExec channel;
    Session session;

    public Ssh(String ip, String user, String pw) {
        this.pw = pw;
        this.user = user;
        this.ip = ip;
    }

    public void disconnect() throws IOException {

        in.close();
        w.close();
        channel.disconnect();
        session.disconnect();
    }

    public BufferedReader getInputStream() {
        return in;

    }

    public BufferedReader getErrStream() {
        return err;

    }


    public void run(String cmd, String msisdn, String rg) {
        try {
            JSch jsch = new JSch();
            session = jsch.getSession(user, ip, 22);
            session.setPassword(pw);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            //System.out.println(user + ip + pw);
            session.setConfig(config);
            session.setConfig("kex", "diffie-hellman-group1-sha1");
            session.connect();
            channel = (ChannelExec) session.openChannel("exec");
            in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            err = new BufferedReader(new InputStreamReader(channel.getErrStream()));
            w = new BufferedWriter(new OutputStreamWriter(channel.getOutputStream()));
            App.print(cmd);
            channel.setCommand(cmd);
            //channel.setCommand("OPENWINHOME=/usr/openwin; export OPENWINHOME; LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/openwin/lib; PATH=${PATH}:/usr/ccs/bin:/usr/openwin/bin:/usr/dt/bin:/usr/sbin:/opt/sun/bin:/opt/VRTS/bin:/etc/vx/bin:/opt/VRTSob/bin:/opt/VRTSvlic/bin:/opt/SUNWvts/bin:/opt/SUNWpcnfs/bin:/usr/cluster/bin:/usr/cluster/lib/sc:/usr/cluster/dtk/bin:/opt/SUNWesm/bin:/usr/opt/SUNWesm/sbin:/usr/opt/SUNWscm/sbin:/opt/tarantella/bin:/opt/SUNWut/bin:/opt/SUNWut/sbin:/opt/SUNWuttsc/bin:/opt/SUNWSMS/bin:/opt/SUNWexplo/bin:/opt/SUNWsneep/bin:/opt/CTEact/bin:/opt/SUNWsamfs/bin:/opt/SUNWsamfs/sbin:/opt/SUNWstm/bin:/opt/SUNWjet/bin:/opt/SUNWcest/bin:/opt/rsc/bin:/opt/SUNWcacao/bin:/opt/sfw/bin:/opt/SUNWldm/bin:/opt/SUNWsesscs/cli/bin:/opt/SUNWswasr/bin/asr:/opt/SUNWxvmoc/bin;export PATH LD_LIBRARY_PATH;" + cmd);
            channel.connect();
            char msg;
            String line = "";

            new LogThrower().start();
            int i = 0;
            while ((msg = (char) in.read()) != (char) -1) {
                System.out.print(msg);
                line += msg;
                if (line.equals("SIM>") && i == 0) {
                    w.write("simple -msisdn " + msisdn + " -rg "+rg+" -loop 100\n");
                    w.flush();
                    i++;
                }

                if (line.equals("SIM>") && i == 1) {
                    w.write("exit\n");
                    w.flush();
                    i++;
                }
                if (line.equals("Socket closed! Press 'ENTER' to quit.")) {
                    w.write("\n");
                    w.flush();
                }
                if (line.equals("Console Server is stopped. Closing console.")) {
                    w.write("\n");
                    w.flush();this.disconnect();break;
                }
                if (msg == '\n')
                    line = "";
            }


        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("SSH ERROR " + ip + user);
            System.exit(1);
        }
    }

    class LogThrower extends Thread {

        public void run() {
            String msg;
            try {
                while ((msg = err.readLine()) != null) {

                    System.out.println(msg);

                }
                err.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
