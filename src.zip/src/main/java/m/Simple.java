package m;

import com.sun.org.apache.bcel.internal.generic.LADD;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.swing.*;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.text.Document;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import static m.App.msisdn;
import static m.App.tb;

public class Simple extends JPanel {
    final static JCheckBox checkMed = new JCheckBox("CCS & Mediation", true);
    final static JCheckBox cbRate = new JCheckBox("Rating", true);
    final static JCheckBox cbBip = new JCheckBox("BIP", true);
    final static JCheckBox cbInv = new JCheckBox("Invoice", true);
    final static JCheckBox cbJrn = new JCheckBox("Journal", true);
    final static JCheckBox cbBck = new JCheckBox("Backout(rollback) BIP&PostBill", false);
    static String campaign = "";

    private JTextField[] fields;
    static CutCopyPastActionSupport support;

    // Create a form with the specified labels, tooltips, and sizes.
    public Simple(String[] labels, char[] mnemonics, int[] widths, String[] tips) {
        super(new BorderLayout());

        JPanel labelPanel = new JPanel(new GridLayout(labels.length, 1));
        JPanel fieldPanel = new JPanel(new GridLayout(labels.length, 1));
        add(labelPanel, BorderLayout.WEST);
        add(fieldPanel, BorderLayout.CENTER);
        fields = new JTextField[labels.length];

        for (int i = 0; i < labels.length; i += 1) {
            fields[i] = new JTextField();
            support = new CutCopyPastActionSupport();
                support.setPopup(fields[i]);
            if (i < tips.length)
                fields[i].setToolTipText(tips[i]);
            if (i < widths.length)
                fields[i].setColumns(widths[i]);
            fields[i].setDragEnabled(true);
            final UndoManager undoManager = new UndoManager();
            Document doc = fields[i].getDocument();

            doc.addUndoableEditListener(new UndoableEditListener() {
                @Override
                public void undoableEditHappened(UndoableEditEvent e) {

                    undoManager.addEdit(e.getEdit());

                }
            });
            InputMap im = fields[i].getInputMap(JComponent.WHEN_FOCUSED);
            ActionMap am = fields[i].getActionMap();

            im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()), "Undo");
            im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Y, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()), "Redo");

            am.put("Undo", new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        if (undoManager.canUndo()) {
                            undoManager.undo();
                        }
                    } catch (CannotUndoException exp) {
                        exp.printStackTrace();
                    }
                }
            });
            am.put("Redo", new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        if (undoManager.canRedo()) {
                            undoManager.redo();
                        }
                    } catch (CannotRedoException exp) {
                        exp.printStackTrace();
                    }
                }
            });
            JLabel lab = new JLabel(labels[i], JLabel.RIGHT);
            lab.setLabelFor(fields[i]);
            if (i < mnemonics.length)
                lab.setDisplayedMnemonic(mnemonics[i]);

            labelPanel.add(lab);
            JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
            p.add(fields[i]);
            fieldPanel.add(p);
        }

    }

    public String getText(int i) {
        return (fields[i].getText());
    }

    static class setImage {
        void setIcon(JFrame frame) {
            String img = "";
            if (this.hashCode() % 2 == 0)
                img = "mumbly.jpg";
            else
                img = "meerkat.jpg";
            frame.setIconImage(new ImageIcon(getClass().getClassLoader().getResource(img)).getImage());
        }

        void setMeerkat(JFrame frame) {
            String img = "meerkat.jpg";
            frame.setIconImage(new ImageIcon(getClass().getClassLoader().getResource(img)).getImage());
        }
    }


    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            //        App.checkInvoiceTags("INACTIVE_DATE,29991230000000,IS_BASE_GTRA,N,DT-ODENE,103658330".split(","), "ip_20190250_132509_[03-CORP].kfx.xml");
            //App.checkInvoiceTags("DT-PNTTOP,3846000000".split(","), "ip_20190253_268142_[04-CONS].kfx.xml");
            //      InvoiceChecker inv = new InvoiceChecker("ip_20190253_268142_[04-CONS].kfx.xml");
            //tb=new Testbook(  "Testbook.txt").getLogger();
            //inv.checkPrices("INACTIVE_DATE,29991230000000");
            //  inv.checkMAFDiscountRatio("10");
            //TestDataSource ds= new TestDataSource();
           /* System.out.println(ds.getDataIndInv("TBMM04"));
            System.out.println(  ds.getVoiceIndJrn("TBMM04"));
            System.out.println(    ds.getVoiceIndIptJrn("TBMM04"));
            System.out.println(  ds.getDataIndJrn("TBMM04"));
            System.out.println(  ds.getDataIndIptJrn("TBMM04"));*/
            //System.out.println(new BigDecimal("1").divide(new BigDecimal("3"),RoundingMode.HALF_UP).toString());
            //  String pa=new BigDecimal(1).multiply(new BigDecimal("0.80")).toString();
            // System.exit(1);
            System.out.println("Usage: java -jar OtoCBU.jar <msisdn> [-d<dateOfCDR>] [-k\"<grepKey1|grepKey2..>\"] [-i<ExpectedInvoiceTagName1,ExpectedTagValue1>..] [-j<ExpectedJournalTagName1,ExpectedTagValue1>..] [-m<MAFDiscountPercent>] [-t<MainTariffPrice>] [-da<discountAmountInInvoice>] [-p<penaltyAmountInInvoice>] [-auto -c<CampaignCode>]\n" + "-auto is for reading journal and invoice tags from arbor.MAF_KENAN_JNL table\ndateOfCDR option is to search that month's archived cdrs besides today's.\n grepkeys parameters are prices or offer or product keys that should be filtered in, to avoid (filter out) unwanted CDRs.\n" +
                    " Example: java -jar OtoCBU.jar 5491112233\n Example: java -jar OtoCBU.jar 5480001122 -d201810 -iDT-PNTTOP,22000000,DT-INDIR,1230000 -jET-PNTTOP,22 -m30\n Example: java -jar OtoCBU.jar 5480001122 -d201810 -k\"11000000|249000000|375000000\"\n Example: java -jar OtoCBU.jar 5480001122 -k\"11000000|249000000|375000000\"");
            // System.out.println("INFO : Sysdate may need to be TODAY for healthy rating. jar will ask you to change sysdate before BIP");
            String[] labels = {"MSISDN example:5491112233 ", "CDR Archive Date (Optional) ex:201810 ", " Expected Prices or OfferIDs in CDRs (Optional) ex:11000000,40001 ", " Invoice tags and prices to check ex:DT-PNTTOP,2200000,DT-INDIR,1230000 ", " Journal tags and prices to check ex:IT-PNTTOP,22,IT-INDIR,1.23 ", " Expected MAF Discount Percent ex:20 ", " Expected MAF fee in invoice (Before discounts) "};
            char[] mnemonics = {'M', 'A', 'E', 'I', 'J', 'D', 'F'};
            int[] widths = {15, 8, 36, 36, 36, 4, 9};
            String[] descs = {"GSM Number", "CDR Backup Date (Optional)", "Prices or OfferIDs to filter from CDRs (Optional)", "Expected Invoice tags and their expected values (All are comma separated) (Optional)", "Expected Journal tags and their expected values (All are comma separated) (Optional)", "INDIRI / ( GORGPRF + HABBUDF ) * 100", "Main Tariff Fee * 1,000,000"};
            final Simple form = new Simple(labels, mnemonics, widths, descs);
            final JCheckBox c = new JCheckBox("Cyan Mode  ");
            final JCheckBox s = new JCheckBox("No Interaction Mode (Nonstop run)  ");
            JButton submit = new JButton("RUN TEST");

            submit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (form.getText(0).isEmpty()) {
                        Object[] opt = {" YES "};
                        Toolkit.getDefaultToolkit().beep();
                        JOptionPane.showOptionDialog(form, "MSISDN cannot be empty", "Missing Input",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE,
                                null, opt, null);
                        return;
                    }
                    String arg = form.getText(0).trim();
                    if (!form.getText(1).isEmpty())
                        arg += " -d" + form.getText(1).trim();
                    if (!form.getText(2).isEmpty())
                        arg += " -k" + form.getText(2).replace("|", "_").replace(",", "_").trim();
                    if (!form.getText(3).isEmpty())
                        arg += " -i" + form.getText(3).replace(",", "_").trim();
                    if (!form.getText(4).isEmpty())
                        arg += " '-j" + form.getText(4).replace(",", "_").trim() + "'";
                    if (!form.getText(5).isEmpty())
                        arg += " -m" + form.getText(5).trim().trim();
                    if (!form.getText(6).isEmpty())
                        arg += " -t" + form.getText(6).trim().trim();
                    arg += " " + s.isSelected() + " " + checkMed.isSelected() + " " + cbRate.isSelected() + " " + cbBck.isSelected() + " " + cbBip.isSelected() + " " + cbInv.isSelected() + " " + cbJrn.isSelected();
                    // System.out.println("cmd /c start cmd.exe /K \"java -jar OtoCBU.jar "+arg+"\"");
                    System.out.println("cmd /c start powershell.exe -command \"java -jar OtoCBU.jar " + arg + "\"");
                    try {
                        if (c.isSelected())
                            Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"Cyan\\\";" +
                                    "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar " + arg + "\"");
                        else
                            Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized  -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"DarkGreen\\\";" +
                                    "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar " + arg + "\"");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            JMenu ab = new JMenu("About");
            final JFrame f = new JFrame("AUToCBU");
            new setImage().setIcon(f);
            JMenuItem jMenuThx = new JMenuItem(new AbstractAction("THANKS") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Object[] options = {"  THANKS!  "};

                    if (JOptionPane.showOptionDialog(f, "" +
                                    "                                AGENDA:\n                                --------------------------\n" +
                                    "                                CSS CDR Collection\n" +
                                    "                                Mediation\n" +
                                    "                                Rating\n" +
                                    "                                BIP\n" +
                                    "                                Invoice\n" +
                                    "                                Journal\n\n" +
                                    "                                DEVELOPED BY:\n                                --------------------------\n                                ALİ ULVİ TALİPOGLU\n\n" +
                                    "                                THANKS:\n                                --------------------------\n                                AYHAN DAŞGIN\n\n"
                            , "About & Credits",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                            null, options, null) == 0) {
                        f.setTitle(f.getTitle() + " \u2661");
                        f.repaint();
                    }
                    // JOptionPane.showInternalMessageDialog(f,"      THANKS\n\nALİ ULVİ TALİPOGLU","Credits",JOptionPane.INFORMATION_MESSAGE);

                }
            });
            ab.add(jMenuThx);
            JMenuBar menuBar = new JMenuBar();
            menuBar.add(support.getMenu());
            menuBar.add(ab);
            f.setJMenuBar(menuBar);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.getContentPane().add(form, BorderLayout.NORTH);
            JPanel b = new JPanel();
            final JButton button2 = new JButton("Automatically fill expected Invoice & Journal tags and prices from a Handset / Accessory / VAS campaign CRD");
            b.setMaximumSize(new Dimension(29, 5));
            b.add(button2);
b.setLayout(new BoxLayout(b,BoxLayout.PAGE_AXIS));
            JButton whatsAppusage = new JButton("Make Comm. Pass Usage");
            whatsAppusage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (form.getText(0).isEmpty()) {
                        Object[] opt = {" Sure. "};
                        Toolkit.getDefaultToolkit().beep();
                        JOptionPane.showOptionDialog(form, "MSISDN can't be empty", "Missing Input",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE,
                                null, opt, null);
                        return;
                    }
                    try {
                        Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized  -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"Cyan\\\";" +
                                "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar  90"+form.getText(0)+" 32 \"");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            JButton usage = new JButton("Make Data Usage");
            usage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (form.getText(0).isEmpty()) {
                        Object[] opt = {" Sure. "};
                        Toolkit.getDefaultToolkit().beep();
                        JOptionPane.showOptionDialog(form, "MSISDN shan't be empty", "Missing Input",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE,
                                null, opt, null);
                        return;
                    }
                    try {
                        Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized  -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"Cyan\\\";" +
                                "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar  90"+form.getText(0)+" 1 \"");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            b.add(usage);
            JButton naviusage = new JButton("Make Navi. Pass Usage");
            naviusage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (form.getText(0).isEmpty()) {
                        Object[] opt = {" Sure. "};
                        Toolkit.getDefaultToolkit().beep();
                        JOptionPane.showOptionDialog(form, "MSISDN can't be empty", "Missing Input",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE,
                                null, opt, null);
                        return;
                    }
                    try {
                        Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized  -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"Cyan\\\";" +
                                "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar  90"+form.getText(0)+" 60 \"");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            b.add(naviusage);            b.add(whatsAppusage);

            JButton gfep =new JButton("Check SMS");
            b.add(gfep);
            gfep.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (form.getText(0).isEmpty()) {
                        Object[] opt = {"Sure"};
                        Toolkit.getDefaultToolkit().beep();
                        JOptionPane.showOptionDialog(form, "MSISDN can't be empty", "Missing Input",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE,
                                null, opt, null);
                        return;
                    }
                    try {
                        Runtime.getRuntime().exec("cmd /c start powershell.exe -WindowStyle Maximized  -noexit -command \"$host.UI.RawUI.ForegroundColor = \\\"Cyan\\\";" +
                                "$host.UI.RawUI.BackgroundColor = \\\"Black\\\";clear;java -jar OtoCBU.jar  90"+form.getText(0)+"  \"");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            button2.setMargin(new Insets(4, 4, 4, 4));
            f.getContentPane().add(b);
            button2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                    jfc.setDragEnabled(true);
                    jfc.setDialogTitle("Choose Handset/Accessory/VAS Campaign CRD");
                    jfc.setFileFilter(new FileFilter() {
                        @Override
                        public boolean accept(File f) {
                            if (f.getName().endsWith("xlsx"))
                                return true;
                            return false;
                        }

                        @Override
                        public String getDescription() {
                            return ".xlsx";
                        }
                    });
                    int returnValue = jfc.showOpenDialog(button2);
                    if (returnValue == JFileChooser.APPROVE_OPTION) {
                        File selectedFile = jfc.getSelectedFile();
                        System.out.println(selectedFile.getAbsoluteFile());
                        try {
                            Crd crd = new Crd(selectedFile.getAbsoluteFile());
                            Object[] choices = crd.getCampaignCodes();
                            JTextField tx = new JTextField();
                            Object complexMsg[] = {"Type Campaign Code", tx, "or choose from list"};
                            String campaignCode = (String) JOptionPane.showInputDialog(null, complexMsg,
                                    "Choose Campaign", JOptionPane.QUESTION_MESSAGE, null, // Use
                                    // default
                                    // icon
                                    choices, // Array of choices
                                    null); // Initial choice
                            System.out.println(tx.getText().isEmpty() ? campaignCode : tx.getText());
                            if (campaignCode == null && tx.getText().isEmpty()) {
                                return;
                            }
                            if (!tx.getText().isEmpty()) {
                                campaign = tx.getText();
                                form.fields[3].setText(crd.getInvoiceCheckStr(tx.getText()));
                                form.fields[4].setText(crd.getJournalCheckStr(tx.getText()));
                            } else {
                                campaign = campaignCode;
                                form.fields[3].setText(crd.getInvoiceCheckStr(campaignCode));
                                form.fields[4].setText(crd.getJournalCheckStr(campaignCode));
                            }
                            new setImage().setMeerkat(f);
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
            });
            JPanel checks = new JPanel();
            checks.setLayout(new BoxLayout(checks, BoxLayout.Y_AXIS));
            checks.add(checkMed);
            checks.add(cbRate);
            checks.add(cbBck);
            checks.add(cbBip);
            checks.add(cbInv);
            checks.add(cbJrn);
            f.getContentPane().add(checks, BorderLayout.AFTER_LINE_ENDS);

            JPanel p = new JPanel();

            p.add(c);
            p.add(s);
            p.add(submit);
            f.getContentPane().add(p, BorderLayout.SOUTH);
            f.pack();
            f.setVisible(true);
        } else {

            new App().main1(args);

        }
    }


}