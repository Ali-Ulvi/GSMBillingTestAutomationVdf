package Unix;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Properties;

import static m.App.*;

public class Rate {

     public Rate(){

            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(KENAN_USER, KENAN_HOST, 22);
                session.setPassword(KENAN_PW);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                ChannelExec channel = (ChannelExec) session.openChannel("exec");
                BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                channel.setCommand(String.format("source /etc/profile > /dev/null;source .profile > /dev/null;cd script; ./noCheckRate.sh %s ", msisdn));
                channel.connect();

                String msg = null;
                while ((msg = in.readLine()) != null) {
                    System.out.println(msg);
                }
                channel.disconnect();
                session.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("KENAN ssh ERROR");
                System.exit(22);

            }
        }

}
