package Unix;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;
import java.util.StringTokenizer;

import static m.App.*;

public class Mediator {

    public void Mediate(){
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(CCS_USER, CCS_HOST, 22);
            session.setPassword(CCS_PW);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            System.out.println(CCS_USER + CCS_HOST + CCS_PW);
            session.setConfig(config);
            session.setConfig("kex", "diffie-hellman-group1-sha1");

            session.connect();

            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            print(String.format("cd " + c.cssScriptPath + ";filterCDR.sh %s \"%s\" ", msisdn, params));
            channel.setCommand(String.format("cd " + c.cssScriptPath + ";filterCDR.sh %s \"%s\" ", msisdn, params));
            channel.connect();

            String msg = null;
            while ((msg = in.readLine()) != null) {
                System.out.println(msg);
                if (msg.contains(" fees for ")) {
                    StringTokenizer st = new StringTokenizer(msg);
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    String cdrNameWithDot = st.nextToken();
                    cdrs.add(cdrNameWithDot.substring(0, cdrNameWithDot.lastIndexOf(".unl") + 4));
                }
            }
            channel.disconnect();
            ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();
            for (int i = 0; i < cdrs.size(); i++) {
                print(cdrs.get(i));
                sftpChannel.get(c.cssScriptPath + cdrs.get(i), dir + cdrs.get(i));

            }
            print("cdr file count:" + cdrs.size());
            //print("INFO : Sysdate may need to be TODAY for healthy rating");
            sftpChannel.disconnect();


            session.disconnect();
            if (cdrs.size() == 0) {
                tb.severe("No CCS CDR found");
                System.exit(5);
            }

        } catch (Exception e) {
            e.printStackTrace();
            //System.out.println("CCS SSH OR ftp ERROR");
            tb.severe("CCS SSH OR ftp ERROR");
            System.exit(1);

        }
        print("Please, check CDR fees and press enter for Mediation, or type q and press enter to quit.");
        Scanner scanner = new Scanner(System.in);
        if (s) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("q"))
                System.exit(3);
        }
        //PUT TO MEDIATION
        ArrayList<String> medCdrs = new ArrayList();
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(MEDIATION_USER, MEDIATION_HOST);
            session.setPassword(MEDIATION_PW);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");

            session.setConfig(config);
            session.connect();
            ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();
            String monCode = "", mgrCode = "";
            for (int i = 0; i < cdrs.size(); i++) {
                if (cdrs.get(i).contains("mon")) {
                    monCode = "mon";
                    sftpChannel.put(dir + cdrs.get(i), monin + cdrs.get(i));
                } else {
                    mgrCode = "mgr";
                    sftpChannel.put(dir + cdrs.get(i), mgrin + cdrs.get(i));
                }
            }

            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            print("Mediating...");
            channel.setCommand(String.format("cd script; ./checkMediation.sh " + msisdn + " " + monCode + mgrCode));
            channel.connect();

            String msg = null;
            boolean monExists = false, mgrExists = false;

            while ((msg = in.readLine()) != null) {
                System.out.println(msg);
                if (msg.equals("MGR CDR PROCESSED"))
                    mgrExists = true;
                else if (msg.equals("MON CDR PROCESSED"))
                    monExists = true;
                else if (msg.endsWith(".data"))
                    medCdrs.add(msg);

            }
            channel.disconnect();
            for (int i = 0; i < medCdrs.size(); i++) {
                print("Getting " + medCdrs.get(i));
                String ctrlFile = medCdrs.get(i).replace(".data", ".ctrl");
                sftpChannel.get(medCdrs.get(i), dir + medCdrs.get(i).split("/")[7]);
                sftpChannel.get(ctrlFile, dir + ctrlFile.split("/")[7]);

            }
            sftpChannel.disconnect();
            session.disconnect();
            if (medCdrs.size() == 0) {
                tb.severe("No mediated CDR found. Check Mediation system");
                print("No mediated CDR found. Press enter to continue or type q and press enter to quit");
                if (s) {
                    String input = scanner.nextLine();
                    if (input.equalsIgnoreCase("q"))
                        System.exit(3);
                } else
                    System.exit(3);
            }
        } catch (Exception e) {
            e.printStackTrace();
            //System.out.println("Mediation FTP ERROR");
            tb.severe("Mediation FTP ERROR");
            System.exit(3);

        }

        //put to kenan AND BILL!
        if (medCdrs.size() > 0) {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(KENAN_USER, KENAN_HOST, 22);
                session.setPassword(KENAN_PW);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                String filename = "";
                for (int i = 0; i < medCdrs.size(); i++) {
                    filename = medCdrs.get(i).split("/")[7];
                    print("Sending " + filename);
                    sftpChannel.put(dir + filename, c.kenanPath + filename);
                    sftpChannel.put(dir + filename.replace(".data", ".ctrl"), c.kenanPath + filename.replace(".data", ".ctrl"));

                }
                sftpChannel.disconnect();
                session.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("KENAN ftp ERROR");
                System.exit(22);

            }
        }
    }
}
